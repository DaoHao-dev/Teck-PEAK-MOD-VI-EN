# Changelog

## [1.1.0] - 2026-08-12

### Fixed
- PEAK update compatibility: `BackpackSlot.hasBackpack` → pack presence via `IsEmpty()` / `backpackType`
- PEAK update compatibility: removed broken `RPCA_Revive` patch (revives now use `RPCA_ReviveAtPosition`)

### Added
- **UseFannypack** config — grant Fannypack (id 166) instead of Backpack (id 6)
- **RandomPack** config — each player randomly gets a Backpack or Fannypack (host-only; overrides UseFannypack)

## [1.0.0] - 2026-08-06

### Initial release
- Host-only starter backpacks for gameplay levels (clients do not need the mod)
- Grants sync through vanilla inventory
- **Run start:** backpack when inventory is ready and the player is alive
- **Late join / reconnect (alive):** grant on shore wake (`UnPassOutDone`), not on the brief register window
- **Late join / reconnect (dead):** grant after revive + warp completes
- Skips the DeathOnArrival flicker so a premature grant isn’t dropped and lost before revive
- **GiveBackpackOnAnyRevive** config (default off) — optional pack on any revive when they have none
- Dropping a pack does not grant another (unless revive config is on and they revive later)
- Event-driven only (no periodic scans)
