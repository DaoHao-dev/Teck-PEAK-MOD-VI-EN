# Start With Backpacks 🎒 for PEAK

Everyone starts the climb with a backpack (or fannypack!) — including late joiners and people who disconnect and come back. **Host-only:** only the host needs the mod!

---

## Features

1. **Run start** — all players get a pack once their inventory is ready  
2. **Late joiners / reconnects** — alive joins get one when ready; dead ghosts get one after revive + warp  
3. **Optional revive refill** — host can give a pack to **anyone** revived without one  
4. **Fannypack / random** — host can grant fannypacks instead, or randomize backpack vs fannypack per player  
5. **Host-only** — clients do **not** need this mod installed  
6. **Not a drop refill** — dropping a pack does not grant another (unless they later revive with the revive config on)  

---

## How it works

PEAK’s inventory is **host-authoritative**. This mod only runs grants on the master client, then uses vanilla `AddItem` / inventory sync so unmodded clients still receive the pack.

| Case | What happens |
|------|----------------|
| **1. Normal run start** (airport → `Level_*`) | Queued on character register; granted when inventory exists and they’re alive |
| **2. Late join / reconnect** | Marked mid-run join or reconnect. Alive → grant on shore wake. Dead / DeathOnArrival → grant after revive, once any warp finishes (no grant during the brief flicker-alive window) |
| **3. GiveBackpackOnAnyRevive** | If enabled, every revive can grant a pack when they’re not warping and have no pack |

**What it does *not* do**
- Does not let clients cheat a pack into someone else’s lobby  
- Does nothing outside gameplay levels (airport, menus, etc.)  
- Does not poll every frame — only event / revive / warp-completed hooks  

---

## Configuration

After first launch:  
`BepInEx/config/tony4twentys.Start_With_Backpacks.cfg`

| Option | Default | Meaning |
|--------|---------|---------|
| `GiveBackpackOnAnyRevive` | `false` | `true` = any revive without a pack gets one. `false` = only run-start / late-join / reconnect starters |
| `UseFannypack` | `false` | `true` = grant Fannypack (166) instead of Backpack (6). Ignored if `RandomPack` is on |
| `RandomPack` | `false` | `true` = each player randomly gets Backpack or Fannypack (host picks) |

Works with **[ModConfig](https://thunderstore.io/c/peak/p/PEAKModding/ModConfig/)** if you use it.

---

## Installation

1. Download the `.zip` from Thunderstore.  
2. Extract it into your `BepInEx/plugins/` folder.  
3. Launch the game.

🔥 Or install with a mod manager🔥

**Dependency:** BepInExPack for PEAK

---

## Credits

- **Author:** [tony4twenty](https://www.twitch.tv/tony4twenty)  
- Questions, bugs, or appreciation → [Peak Modding Discord](https://discord.gg/SAw86z24rB)  
- More PEAK mods: [tony4twenty on Thunderstore](https://thunderstore.io/c/peak/p/tony4twenty/)

Happy climbing. 🎒⛰️
