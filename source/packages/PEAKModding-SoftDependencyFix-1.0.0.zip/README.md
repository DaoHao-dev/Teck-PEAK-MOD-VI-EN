# SoftDependencyFix

Fixes ReflectionUtility usage in Vanilla from breaking from mods with soft dependencies.

A soft dependency is when an assembly depends on another assembly or API but only makes use of it if it's available at runtime.

To learn how to soft depend on a mod, see: <https://risk-of-thunder.github.io/R2Wiki/Mod-Creation/C%23-Programming/Mod-Compatibility%3A-Soft-Dependency/>
