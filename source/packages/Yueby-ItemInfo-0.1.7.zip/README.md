# ItemInfo

A mod for PEAK that displays item information panels when the player is holding items.

![Demo](https://Yueby.github.io/picx-images-hosting/peakmod-iteminfo1.webp)

## What it does

Shows detailed information about items, including stats, effects, and special abilities when the player is holding items.

## Installation

1. Install BepInEx
2. Put ItemInfo.dll in `BepInEx/plugins/` folder
3. Start the game

## Community

Find the mod in the [Peak Modding Discord](https://discord.gg/UP3QwAwCmg) under #mod-releases to discuss mod related topics like issues/reports/appreciation.