# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.7] - 2025-08-23

### Fixed
- Fixed pool destroy error

## [0.1.6] - 2025-08-20

### Changed
- Fixed display issues

## [0.1.5] - 2025-08-18

### Added
- Added fontSharedMaterial support for text rendering consistency
- Fixed lanterns text sign

## [0.1.4] - 2025-08-18

### Changed
- Updated README.md with improved descriptions and community Discord link

## [0.1.3] - 2025-08-18

### Removed
- Removed Plugin file dependency

## [0.1.2] - 2025-08-18

### Removed
- Removed PEAKModding-PEAKLib_Stats dependency

## [0.1.1] - 2025-08-18

### Changed
- Updated plugin description and corrected functionality description

## [0.1.0] - 2025-08-17

### Added
- Released ItemInfo plugin
- Implemented player-held item information display functionality
