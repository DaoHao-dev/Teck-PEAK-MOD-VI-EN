# Changelog

## [1.1.0] <br>
- Added RegisterOnJoinedRoom to get when the local player has joined a room.
- Added GetAllPlayerProperties to get all player properties
- The Player whose properties have changed is now also sent in the PlayerProperttyChanged event