# Photon Custom Props Utils

Helps modders easily synchronize room/player properties across all connected clients.

Utilizes Photon RoomProperties and PlayerProperties to make it easier to synchronize properties for all players.

## To Modders
The best way to reach me is through the Photon Custom Props Utils thread on the Peak modding discord server.

[Peak Modding Discord Server](https://discord.gg/SAw86z24rB)


### Guide

First add this mod dll as a project reference for your mod. Then you can add a dependency to the mod to ensure your mod runs after PhotonCustomPropsUtils. 

```csharp
[BepInDependency("com.snosz.photoncustompropsutils", BepInDependency.DependencyFlags.HardDependency)]
```

Or if you dont want to set a dependancy you can just check for IsReady and listen for OnReady.

```csharp
if (PhotonCustomPropsUtilsPlugin.IsReady)
    DoPhotonStuff();
else
    PhotonCustomPropsUtilsPlugin.OnReady += DoPhotonStuff;
```

Then you can create your scoped CustomPropsManager by passing your plugin GUID like so:

```csharp
manager = PhotonCustomPropsUtilsPlugin.GetManager("com.author.modname");
```

This ensures that any properties you listen to are specific to your mod which helps avoid naming conflicts where multiple mods might have similar property names.

To start listening for a property change you can use either RegisterRoomProperty, or RegisterPlayerProperty. You can also set the event type, depending on if its a player or room event you can use RoomEventType.All (for both OnJoinedRoom, and OnRoomPropertyChanged) or either one seperately if you want to handle that logic seperately.

PlayerEventType is similar and can be PlayerEventType.All,  OnPlayerPropertyChanged, and OnJoinedRoom.

For easy usage you can specify the expected type to be received which means you dont have to worry about casting it yourself.

```csharp
// This will be called for either OnJoinedRoom (which runs for the local player), or OnRoomPropertyChanged.
manager.RegisterRoomProperty<bool>("myValue", RoomEventType.All, value =>
{
    storedValue = value; //This is where you handle what to do with the updated property
});
```

```csharp
// This will be called for OnPlayerPropertyChanged.
manager.RegisterPlayerProperty<bool>("myValue", PlayerEventType.OnPlayerPropertyChanged, (targetPlayer, value) =>
{
    storedValue = value; //This is where you handle what to do with the updated property
});
```

To set a new value for a property you can just call SetRoomProperty

```csharp
manager.SetRoomProperty("myValue", newValue);
```

To listen for when the local player has joined a room:

```csharp
manager.RegisterOnJoinedRoom(localPlayer => 
{
	// Do thing
});
```

To get all player properties, or all players with a specific property:

```csharp
var allPlayersProperties = manager.GetAllPlayerProperties<float[]>("targetProperty");
```

Please note that this should not be used in excess such as setting a property every frame. It should be only done in response to client behaviour such as pushing a button.

For further reading about Photon custom properties, the official Photon docs have both information on how it can be used, and the allowed types that are supported.

https://doc.photonengine.com/realtime/current/gameplay/custom-properties

https://doc.photonengine.com/fusion/current/manual/data-transfer/rpcs
