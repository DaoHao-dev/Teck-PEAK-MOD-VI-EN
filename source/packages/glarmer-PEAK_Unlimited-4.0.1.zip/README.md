# PEAK Unlimited

Have more than 4 climbing-enthusiast friends? Want to scale the PEAKs with all of them? Well have I got the solution for you... <br>

![peakunlimited2](https://glarmer.xyz/images/head.png)

Introducing, "PEAK Unlimited", a mod for PEAK which raises the lobby max player count so that you may play with all of your friends, only the host needs to have this mod! 

[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/Q5Q7IFRUH)

- Did you know? You can get help from myself via my [Discord server](https://discord.gg/cjzWT37abR)!

## Features:
- Raises the Max Player Count
- Adds extra marshmallows for all your friends! 
- Configurable via in game menu (F2 to Open) or via an easy to use config file!
- Fixes the end screen (non-hosts can optionally download to also have a fixed end screen)
- Allows the host to press "Next" for the whole lobby on the end screen
- Optionally lock the starting kiosk so only the host can start the game!
- Increases the backpack spawn rate in line with the original balance
- Optionally cram everyone into the helicopter on the end screen!
- Spawns marshmallows for late joiners!
- Compatible with the latest update!

## I'm not the host, should I install this?

__To sum it up:__ 
You don't need to, but you get a few quality of life fixes if you do.

__For more detail:__
Only the host needs to have the mod installed for the player count to be raised, for extra marshmallows and for hotdogs and backpacks to be added. If you install the mod as a client the end screen will appear correctly, with all scout's graphs appearing.

If you play the game in lobbies with more than 8 players, it is especially beneficial to download the mod as a client, since after 8 players you will not get audio sliders for the 9th player onwards and nametags above heads can become inccorect.

## Configuration
- You can open the in game mod menu with F2 - all options can be changed here.
- The mod menu's keybind can be changed both in the menu and from the configuration file
- Configuration can be found at: (steam directory)\PEAK\BepInEx\config\PeakUnlimited.cfg
- The extra marshmallows feature may be turned off in the configuration! (It is on by default)
- The default max is 20, I would recommend lowering this value in the configuration if you know you won't be playing with this many people
- Can override the number of marshmallows and backpacks to a desired value.

## My other mods

- [PEAK Visuals](https://thunderstore.io/c/peak/p/glarmer/PEAK_Visuals/) - Adds a ton of options to improve graphics! (alternatively can be used to potato-ify graphics!)
- [Hide and PEAK](https://thunderstore.io/c/peak/p/glarmer/Hide_and_PEAK_/) - Adds a Hide and Seek gamemode to PEAK!
- [Voice Volume Saver](https://thunderstore.io/c/peak/p/glarmer/PEAK_Voice_Volume_Saver/) - Saves the volume of all your friends, no more adjusting their volume every time you load in!
- [Discplacement](https://thunderstore.io/c/peak/p/glarmer/Discplacement/) - Turns the frisbee into a teleportation device with various balance settings
- [Badges for Boba's Hats](https://thunderstore.io/c/peak/p/glarmer/Badges_For_Bobas_Hats/) - Adds badges so you can earn boba's hats!
- [PEAK Unbound](https://thunderstore.io/c/peak/p/glarmer/PEAK_Unbound/) - Allows you to rebind your keys

## Commissions
Did you know I take commissions? Contact me on discord @glarmer if you'd like to discuss! Alternatively reach out to me via my [Discord server](https://discord.gg/cjzWT37abR). Note: All commissions must go through PayPal for the safety of you as a buyer and me as a seller.

## Recommended Installation

If you are not familiar with modding, I recommend using [r2modman](https://thunderstore.io/package/ebkr/r2modman/) to automatically install mods.

## Manual Installation 
**Only the host needs to install, but there are some fixes that you can benefit from as a client!**

1.) Download Bepinex from [here](https://github.com/BepInEx/BepInEx/releases/download/v5.4.23.3/BepInEx_win_x64_5.4.23.3.zip) <br>
2.) Extract the contents of that zip into your game directory (default: C:\Program Files (x86)\Steam\steamapps\common\PEAK) resulting in a folder that has the following files: <br>
![image](https://github.com/user-attachments/assets/403d9a1d-16a4-409c-a046-bc56141ac0ca) <br>
3.) Start the game and close it again, this does the first time set up for Bepinex. <br>
- Linux users: set the launch option `WINEDLLOVERRIDES="winhttp=n,b" %command%` before running the game.
  
4.) Navigate to ...\PEAK\BepInEx\plugins, Download and extract the PeakUnlimited.dll from "Manual Download" on Thunderstore into this folder. <br>
5.) Run the game <br>

## Important
- DO NOT UNDER ANY CIRCUMSTANCE COMPLAIN ABOUT BUGS TO THE DEVELOPERS WHILE USING MODS. UNINSTALL MODS IF YOU ENCOUNTER BUGS AND THEN REPORT THEM IF THEY ARE STILL PRESENT.
- Please search the PEAK Steam discussions if you face bugs as they are possibly caused by the game and not the mod. If you continue to experience issues then please reach out via the GitHub issues.
- Game may become unstable with high number of players as it requires more system resources.

The only official pages for this mod are as follows:
- Thunderstore: https://thunderstore.io/c/peak/p/glarmer/PEAK_Unlimited/
- GitHub: https://github.com/glarmer/PEAK-Unlimited/
- Nexus: https://www.nexusmods.com/peak/mods/37

Any other site is not run by me and may contain malware. Please make sure to download from an official source.

## Help
- You can find your PEAK folder by **right clicking the game in your Steam library** then > **Manage** > **Browse Local Files**
- You can get help from myself via my [Discord server](https://discord.gg/cjzWT37abR)!
- Please report issues to [the mods github](https://github.com/glarmer/PEAK-Unlimited/), alternatively I will periodically check the [steam guide](https://steamcommunity.com/sharedfiles/filedetails/?id=3501916945&tscn=1750268995)

## Images
- Here are some fun pictures using the mod


![peakunlimited1](https://glarmer.xyz/images/1mNyvy8.png)

![peakunlimited1](https://glarmer.xyz/images/9pnQpW8.png)

![peakunlimited1](https://glarmer.xyz/images/W5183qL.png)

#### Yogscast Using PEAK Unlimited (Click for video!)
[![Yogscast Playing PEAK with PEAK Unlimited](https://img.youtube.com/vi/qvD8aKm7lH8/0.jpg)](https://youtu.be/qvD8aKm7lH8)
