# Changelog

## [4.5.1] - 2026-08-12

### PEAK 2.0.a compatibility
- Fixed campfires not lighting / not interactable after the game update (`Campfire.state` is a property now; old field access crashed `IsInteractible` and blocked all campfire interaction)
- `EnforceRevivePenalty` curse amount now follows vanilla `Ascents.revivalCurse` (0.05 below ascent 7, 0.15 at 7+)

### Petrify
- `HealAllStatuses` / continuous heal now reduce **Petrify** (stored on the character, not the normal status bar)
- New toggles: `HealPetrify`, `BlockPetrify` (used when HealAll / BlockAll are off)
- Compatible with vanilla `ClearAllStatus(excludePetrify: false)` for full Petrify clear

### Morale + Remove Restriction
- Multi-player morale waiting applies **only** when `EnableRemoveRestriction` is on (solo-light path)
- That wait requires **every living lobby player** in morale radius (not merely 2+)
- When Remove Restriction is off, lighting/morale use vanilla gather rules (no extra scout-count gate)
- `EnableSoloMoraleBoost` kept for sync/legacy; morale waiting is controlled by Remove Restriction

### Sync
- Host config schema **v10** (`healPetrify`, `blockPetrify`)

## [4.5.0] - 2026-07-30

### Dynamic Backpacks (new)
- Match campfire backpack count to room player count (late joiners included)
- Optional decrease when players leave (`AllowBackpackDecrease`)
- Extras spawn with slight X/Z scatter so packs do not overlap
- Works with beach/segment backpack spawners (e.g. crashed plane), not only children of the campfire root
- Config lives under the **Dynamic Mallows** section: `EnableDynamicBackpacks`, `AllowBackpackDecrease`

### From 4.4.x (included)
- Dynamic mallows with multiplier, GlizzyChance, and ring placement around the fire
- `MallowMultiplier` typeable in ModConfig (string field); Glizzy/Stamina stay 0–1 sliders
- Unified `MoraleBoostRadius` override (heal, block, NoHunger, gather, unlock)
- `HealAllStatuses` / `BlockAllStatuses` default on; per-type toggles for customization
- `HealInjury` toggle; removed `BlockHunger` / `HealingRadius` / AllowCurse/Hunger
- Remove Restriction solo-light + deferred unlock; hold-revive; EnforceRevivePenalty
- Stronger portable stove detection; host config sync schema v9

## [4.0.0] - 2026-07-28

- Major rewrite: hooks vanilla campfire protection / radius instead of a global coroutine + campfire cache
- Removed forced infinite burn time (vanilla already pauses burn-down while everyone stays in range)
- Host handshake via PEAKLib Core + config sync via PhotonCustomPropsUtils room properties
- Clients follow host settings; mod features disable for clients when the host does not have the mod
- Healing applies once per second (`HealPerSecond`) and only for statuses that are actually present
- Status blocking only affects the local player’s local status gains
- Respawn on progression campfire light (host/master client)
- Portable stoves still excluded
- Hard dependencies: PEAKLib Core + PhotonCustomPropsUtils

## [3.0.0] - 2025-11-14

- Now working after Roots Update
- Now has infinite fires
- Now blocks afflictions while near fire
- Now heals even more afflictions
- More configs

## [2.1.0] - 2025-08-19

- Now works with forever campfires
- One coroutine total, started at StartRun and never spam-started per fire.
- No per-tick object finds. Campfires are cached once and re-cached every 5s (cheap, fires are few).
- Early-out when nothing’s lit. Near-zero work while idle.
- Squared-distance checks (no sqrt) and tick-scaled healing.
- Added Config: TickRateHz lets you tune CPU vs. responsiveness; default 2 Hz.
- Kept respawn-on-light behavior in the Light_Rpc patch. Healing itself is handled by the global loop.

## [2.0.0] - 2025-08-03

- Added new configs
- Added more affliction healing
- Added new config to respawn players at fires
- Added config sync with host
- Now using coroutines and patches instead of updating every frame

## [1.0.0] - 2025-7-4

- Initial release.
