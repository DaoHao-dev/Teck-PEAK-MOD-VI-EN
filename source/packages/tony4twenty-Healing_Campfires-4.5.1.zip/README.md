# Healing Campfires 🔥🩹

Now you can do more than just block or heal afflictions and revive people at campfires!
You can also remove restrictions to allow anyone to light the fire at any time!
It will not remove the previous segment where your friends are still climbing.
It will not unlock the next segment till everyone is in the morale radius.
Morale boosts will not trigger until everyone is alive and within the radius (when Remove Restriction is on).
You can also revive players from the fire at any time with an optional config toggle to revive passed out players that havent died yet!
Want more glizzys? Then do it! Want more backpacks? Then do it! Now you can have a mallow or glizzy spawn for every player in the lobby and THEN some with the new multiplier setting!

They are also dynamic (see gif below). Players can join or leave mid game and it will increase or decrease the amount at campfires!
You can toggle off the decrease config so they never dissapear when someone leaves the lobby mid-run as well!

**Lit campfires** can:
- 🩹 **Heal** afflictions over time — including **Petrify** (all by default, or pick per type)
- 🛡️ **Block** new negative statuses while you rest at the fire (Petrify included when BlockAll is on)
- 💀 **Revive** dead players on light / hold-interact (optional passed-out)
- 🔦 **Solo-light** without everyone nearby, then unlock the next segment when the squad gathers
- 🍫 **Dynamic mallows** sized to player count, with Glizzy/Marshmallow chance and ring placement
- 🎒 **Dynamic backpacks** sized to player count (scattered so they don’t stack)

**Host config sync** — clients follow the host via PEAKLib handshake + PhotonCustomPropsUtils room properties. If the host lacks the mod, clients disable Healing Campfires for that lobby.

![Dynamic Mallows and Backpack Spawns](https://i.imgur.com/p1fAya1.gif)

- 🗣️ [Peak Modding Discord](https://discord.gg/SAw86z24rB) → `#mod-releases`

---

## 🛠️ Features

### Heal & Block
- Plug-and-play: `HealAllStatuses` + `BlockAllStatuses` default **on** (includes **Petrify**)
- Turn those off to customize with per-affliction toggles (`HealPetrify` / `BlockPetrify` included)
- Heals once per second (`HealPerSecond`) only for statuses that are present
- Petrify uses the game’s petrify amount API (`SubtractStatus` / `ClearAllStatus(excludePetrify: false)`)
- Uses each campfire’s `moraleBoostRadius` (optional override under Morale Boosts)
- Hunger **prevention** is vanilla `NoHunger`; use Heal to clear existing hunger
- Local-only status blocking (does not break other players’ network sync)
- Portable stoves ignored

### Remove Restriction
- Light without everyone in range
- Morale boost + next-segment unlock wait until **every living lobby player** is in morale radius (host decides)
- This multi-player morale wait only applies when Remove Restriction is on (that’s when solo-light is possible in a multi lobby)
- When off, lighting/morale use vanilla everyone-in-range rules
- Hold-to-revive on already-lit campfires when respawn is enabled

### Campfire Revives
- Revive on progression light + hold-interact while lit
- Optional `RevivePassedOut`
- `EnforceRevivePenalty`: off = vanilla curse (`Ascents.revivalCurse`) + hunger; on = force both on campfire revives (Block ignored; Heal can still clear)

### Dynamic Mallows
- Target pile size = room player count (× multiplier if enabled)
- Optional trim when players leave
- `GlizzyChance` 0.00–1.00 for vanilla spawns **and** extras (sometimes 1 marshmallow makes it in lol)
- Foods placed in rings around the fire with spacing

### Dynamic Backpacks
- Target backpack count = room player count
- Optional trim when players leave
- Extras scatter on X/Z near the spawner (no stacking)
- Finds beach/segment spawners (e.g. crashed plane) near the campfire

### Morale Boosts
- With Remove Restriction on: morale waits for the full living lobby in radius
- Configurable morale stamina (0.00–1.00, vanilla 0.25)
- Optional `MoraleBoostRadius` override for heal, block, NoHunger, gather, and unlock
- `EnableSoloMoraleBoost` is legacy (kept for sync); waiting is controlled by Remove Restriction

---

## ⚙️ Config Options

Config file:  
`BepInEx/config/tony4twentys.Healing_Campfires.cfg`  
(or edit in-game with **ModConfig**)

### Dynamic Mallows
| Setting | Default | Description |
|---------|---------|-------------|
| `EnableDynamicMallows` | true | Match food pile size to room player count |
| `AllowMallowDecrease` | true | Trim unclaimed pile items when players leave |
| `EnableMallowMultiplier` | false | Multiply target by `MallowMultiplier` |
| `MallowMultiplier` | 2 | Typeable whole number (min 1). Target = players × this |
| `GlizzyChance` | 0.25 | Slider 0.00–1.00. Chance each food is a Glizzy |
| `EnableDynamicBackpacks` | true | Match backpack count to room player count |
| `AllowBackpackDecrease` | true | Trim unclaimed backpacks when players leave |

### Morale Boosts
| Setting | Default | Description |
|---------|---------|-------------|
| `EnableSoloMoraleBoost` | true | Legacy / sync only. Morale waiting follows Remove Restriction |
| `MoraleBoostStamina` | 0.25 | Slider 0.00–1.00. Extra stamina from morale boost |
| `MoraleBoostRadius` | 0 | Override campfire radius (`0` = vanilla per-campfire) |

### Remove Restriction
| Setting | Default | Description |
|---------|---------|-------------|
| `EnableRemoveRestriction` | true | Solo-light; defer unlock/morale until every living player is in radius |

### Campfire Revives
| Setting | Default | Description |
|---------|---------|-------------|
| `RespawnOnCampfire` | true | Revive on light + hold-interact while lit |
| `RevivePassedOut` | false | Also revive fully passed-out players |
| `EnforceRevivePenalty` | false | Force curse+hunger on campfire revives only |

### Heal Afflictions
| Setting | Default | Description |
|---------|---------|-------------|
| `HealAfflictions` | true | Master heal toggle |
| `HealPerSecond` | 0.025 | Amount removed once per second |
| `HealAllStatuses` | true | Heal every supported status incl. Petrify (ignores per-type toggles) |
| `HealInjury` / `HealDrowsy` / … / `HealPetrify` | false | Used only when `HealAllStatuses` is off |

### Block Afflictions
| Setting | Default | Description |
|---------|---------|-------------|
| `BlockNegativeStatus` | true | Master block toggle |
| `BlockAllStatuses` | true | Block all positive status gains incl. Petrify (ignores per-type toggles) |
| `BlockInjury` / `BlockCold` / … / `BlockPetrify` | false | Used only when `BlockAllStatuses` is off |

**Cfg note:** Old keys (`HealingRadius`, `AllowCurse`, `AllowHunger`, `BlockHunger`, etc.) may linger — safe to delete; unused.

---

## 📦 Installation

1. Download via [Thunderstore](https://thunderstore.io/c/peak/)
2. Place the `.dll` in `/PEAK/BepInEx/plugins/`
3. Launch once to generate config  
🔥 or use a Mod Manager 🔥

---

## 📦 Dependencies

- [BepInExPack_PEAK](https://thunderstore.io/c/peak/p/BepInEx/BepInExPack_PEAK/)
- [PEAKLib Core](https://thunderstore.io/c/peak/p/PEAKModding/PEAKLib_Core/)
- [PhotonCustomPropsUtils](https://thunderstore.io/c/peak/p/Snosz/PhotonCustomPropsUtils/)

---

## 📣 Feedback

Suggestions or issues: [PEAK Modding Discord](https://discord.gg/SAw86z24rB)

---

## 👨‍🍳 Credits

**Author** [tony4twenty](https://www.twitch.tv/tony4twenty)  
**My Other Mods** [tony4twenty](https://thunderstore.io/c/peak/p/tony4twenty/)

---

🔥 Stay warm. Stay healed.
